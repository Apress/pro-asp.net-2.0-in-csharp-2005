using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net;
using localhost;

public partial class WindowsAuthenticationSecurityTest : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{

	}
	protected void cmdUnauthenticated_Click(object sender, EventArgs e)
	{
		SecureService securedService = new SecureService();
		try
		{
			lblInfo.Text = securedService.TestAuthenticated();
		}
		catch (Exception err)
		{
			lblInfo.Text = err.Message;
		}

	}
	protected void cmdAuthenticated_Click(object sender, EventArgs e)
	{
		SecureService securedService = new SecureService();

		// Specity some user credentials for the web service.
		NetworkCredential credentials = new NetworkCredential(
			txtUserName.Text, txtPassword.Text);
		securedService.Credentials = credentials;

		lblInfo.Text = securedService.TestAuthenticated();

	}
}
